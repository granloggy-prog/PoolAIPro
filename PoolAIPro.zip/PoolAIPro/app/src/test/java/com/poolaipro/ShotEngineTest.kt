package com.poolaipro

import com.poolaipro.core.*
import org.junit.Assert.*
import org.junit.Test

class ShotEngineTest {
    // 880 x 440 table, ball radius 10 (diameter = length / 44)
    private val table = Table(0.0, 0.0, 880.0, 440.0, 10.0)

    @Test fun directShotGhostBallIsTwoRadiiBehindTarget() {
        val cue = Ball(Vec(200.0, 220.0), BallKind.CUE)
        val target = Ball(Vec(440.0, 220.0), BallKind.SOLID)
        val a = ShotEngine.analyse(table, listOf(cue, target), EngineConfig(maxRails = 0))
        for (s in a.shots) {
            val d = (s.objectPath[1] - s.objectPath[0]).unit()
            assertEquals(20.0, s.ghost.dist(target.pos), 1e-6)
            assertEquals(1.0, d.dot((target.pos - s.ghost).unit()), 1e-6)
        }
    }

    @Test fun cornerPocketShotIsFoundAndRanked() {
        val cue = Ball(Vec(300.0, 300.0), BallKind.CUE)
        val target = Ball(Vec(150.0, 120.0), BallKind.SOLID)
        val a = ShotEngine.analyse(table, listOf(cue, target), EngineConfig(maxRails = 0))
        assertTrue(a.shots.isNotEmpty())
        assertEquals(0, a.shots[0].pocket) // top-left
    }

    @Test fun blockedPathIsRejected() {
        val cue = Ball(Vec(300.0, 300.0), BallKind.CUE)
        val target = Ball(Vec(150.0, 120.0), BallKind.SOLID)
        val blocker = Ball(Vec(225.0, 210.0), BallKind.STRIPE)
        val a = ShotEngine.analyse(table, listOf(cue, target, blocker), EngineConfig(maxRails = 0, group = Group.SOLIDS))
        assertTrue(a.shots.none { it.pocket == 0 })
    }

    @Test fun bankShotsReflectOffCushions() {
        val cue = Ball(Vec(150.0, 300.0), BallKind.CUE)
        val target = Ball(Vec(440.0, 330.0), BallKind.SOLID)
        val a = ShotEngine.analyse(table, listOf(cue, target), EngineConfig(maxRails = 2, maxShots = 50))
        assertTrue(a.shots.any { it.isBank })
        for (s in a.shots.filter { it.isBank }) assertTrue(s.rails.size in 1..2)
    }
}
