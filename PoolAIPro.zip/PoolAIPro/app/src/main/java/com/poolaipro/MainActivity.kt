package com.poolaipro

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings as SysSettings
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var overlayBtn: MaterialButton
    private lateinit var startBtn: MaterialButton
    private lateinit var stopBtn: MaterialButton

    private val projectionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val data = res.data
        if (res.resultCode == RESULT_OK && data != null) {
            val i = Intent(this, AnalysisService::class.java)
                .setAction(AnalysisService.ACTION_START)
                .putExtra(AnalysisService.EXTRA_CODE, res.resultCode)
                .putExtra(AnalysisService.EXTRA_DATA, data)
            ContextCompat.startForegroundService(this, i)
            status.postDelayed({ refresh() }, 700)
        } else {
            Toast.makeText(this, "Screen sharing was not approved — nothing is captured.", Toast.LENGTH_LONG).show()
        }
    }

    private val notifLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { askProjection() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        overlayBtn = findViewById(R.id.btnOverlay)
        startBtn = findViewById(R.id.btnStart)
        stopBtn = findViewById(R.id.btnStop)

        overlayBtn.setOnClickListener {
            startActivity(Intent(SysSettings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        startBtn.setOnClickListener {
            if (!SysSettings.canDrawOverlays(this)) {
                Toast.makeText(this, "Grant “Display over other apps” first", Toast.LENGTH_SHORT).show(); return@setOnClickListener
            }
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) else askProjection()
        }
        stopBtn.setOnClickListener {
            startService(Intent(this, AnalysisService::class.java).setAction(AnalysisService.ACTION_STOP))
            status.postDelayed({ refresh() }, 500)
        }
    }

    /** System dialog: the user picks what to share (choose the 8 Ball Pool app, or the whole screen). */
    private fun askProjection() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val canOverlay = SysSettings.canDrawOverlays(this)
        val running = AnalysisService.running
        overlayBtn.text = if (canOverlay) "Overlay permission ✓" else "1 · Allow display over other apps"
        overlayBtn.isEnabled = !canOverlay
        startBtn.isEnabled = canOverlay && !running
        stopBtn.isEnabled = running
        status.text = when {
            running -> "Analysis running. Switch to your game — the floating panel controls the overlay."
            !canOverlay -> "Grant the overlay permission, then start analysis."
            else -> "Ready. Start Analysis will ask you to approve screen sharing."
        }
    }
}
