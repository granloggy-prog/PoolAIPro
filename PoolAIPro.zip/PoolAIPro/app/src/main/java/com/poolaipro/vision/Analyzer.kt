package com.poolaipro.vision

import com.poolaipro.Settings
import com.poolaipro.core.Analysis
import com.poolaipro.core.EngineConfig
import com.poolaipro.core.Group
import com.poolaipro.core.ShotEngine
import com.poolaipro.core.Table
import kotlin.math.abs

/** What the overlay needs to draw one frame. */
class UiState(val analysis: Analysis?, val fw: Int, val fh: Int, val status: String)

class Analyzer {
    private val detector = TableDetector()
    private var lastTable: Table? = null

    fun process(f: Frame): UiState {
        val det = detector.detect(f, Settings.cushionInsetPct.toDouble(), Settings.ballScale.toDouble())
        if (det == null) {
            return UiState(null, f.width, f.height, "Searching for table… open a match (landscape)")
        }
        val t = smooth(det.table)
        val cfg = EngineConfig(
            maxRails = Settings.maxRails,
            group = Group.values()[Settings.groupOrdinal.coerceIn(0, 3)],
            maxShots = Settings.maxShots
        )
        val analysis = ShotEngine.analyse(t, det.balls, cfg)
        val status = when {
            analysis.cue == null -> "Table OK · cue ball not found"
            analysis.shots.isEmpty() -> "Balls: ${det.balls.size} · no clear shot (blocked: ${analysis.blockedCount})"
            else -> {
                val b = analysis.shots[0]
                val kind = if (b.isBank) "${b.rails.size}-rail bank" else "direct"
                "Balls: ${det.balls.size} · best: $kind ${b.ease}% · cut ${b.cutAngleDeg.toInt()}°"
            }
        }
        return UiState(analysis, f.width, f.height, status)
    }

    private fun smooth(t: Table): Table {
        val lt = lastTable
        val out = if (lt != null &&
            abs(lt.left - t.left) < 0.03 * lt.width && abs(lt.right - t.right) < 0.03 * lt.width &&
            abs(lt.top - t.top) < 0.03 * lt.width && abs(lt.bottom - t.bottom) < 0.03 * lt.width
        ) {
            fun mix(a: Double, b: Double) = a * 0.75 + b * 0.25
            Table(mix(lt.left, t.left), mix(lt.top, t.top), mix(lt.right, t.right), mix(lt.bottom, t.bottom), mix(lt.ballR, t.ballR))
        } else t
        lastTable = out
        return out
    }
}
