package com.poolaipro.vision

import com.poolaipro.core.Ball
import com.poolaipro.core.BallKind
import com.poolaipro.core.Table
import com.poolaipro.core.Vec
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class Frame(val width: Int, val height: Int, val pixels: IntArray)
class Detection(val table: Table, val balls: List<Ball>)

/**
 * Pure-Kotlin detector working on one captured frame (ARGB ints):
 *  1. finds the dominant saturated hue = table cloth, takes its bounding box as the playfield;
 *  2. everything inside that is not cloth is a ball candidate; a distance transform + "peeling"
 *     separates touching balls and ignores thin lines (the game's own guide, cue stick);
 *  3. balls are classified by how much white / black they contain.
 */
class TableDetector {
    private var h = IntArray(0)
    private var s = IntArray(0)
    private var v = IntArray(0)
    private var cloth = BooleanArray(0)

    private fun hueDiff(a: Int, b: Int): Int {
        val d = abs(a - b)
        return min(d, 360 - d)
    }

    fun detect(f: Frame, cushionInsetPct: Double, ballScale: Double): Detection? {
        val w = f.width
        val hh = f.height
        val n = w * hh
        if (h.size != n) { h = IntArray(n); s = IntArray(n); v = IntArray(n); cloth = BooleanArray(n) }
        val px = f.pixels

        for (i in 0 until n) {
            val c = px[i]
            val r = (c shr 16) and 255
            val g = (c shr 8) and 255
            val b = c and 255
            val mx = max(r, max(g, b))
            val mn = min(r, min(g, b))
            val d = mx - mn
            v[i] = mx * 100 / 255
            s[i] = if (mx == 0) 0 else d * 100 / mx
            h[i] = when {
                d == 0 -> 0
                mx == r -> ((60 * (g - b) / d) + 360) % 360
                mx == g -> 60 * (b - r) / d + 120
                else -> 60 * (r - g) / d + 240
            }
        }

        // 1. dominant hue
        val hist = IntArray(36)
        var samples = 0
        var y = 0
        while (y < hh) {
            var x = 0
            while (x < w) {
                val i = y * w + x
                if (s[i] >= 35 && v[i] >= 25) { hist[h[i] / 10 % 36]++; samples++ }
                x += 2
            }
            y += 2
        }
        if (samples < 500) return null
        var bestBin = 0
        var bestSum = -1
        for (b in 0 until 36) {
            val sum = hist[b] + hist[(b + 1) % 36] + hist[(b + 35) % 36]
            if (sum > bestSum) { bestSum = sum; bestBin = b }
        }
        val dom = bestBin * 10 + 5

        // 2. cloth mask + bounding box via row/column projections
        val rowCnt = IntArray(hh)
        val colCnt = IntArray(w)
        for (yy in 0 until hh) {
            for (xx in 0 until w) {
                val i = yy * w + xx
                val isCloth = s[i] >= 28 && v[i] >= 15 && hueDiff(h[i], dom) <= 20
                cloth[i] = isCloth
                if (isCloth) { rowCnt[yy]++; colCnt[xx]++ }
            }
        }
        val maxRow = rowCnt.max()
        val maxCol = colCnt.max()
        if (maxRow == 0 || maxCol == 0) return null
        val top = rowCnt.indexOfFirst { it >= 0.45 * maxRow }
        val bottom = rowCnt.indexOfLast { it >= 0.45 * maxRow }
        val left = colCnt.indexOfFirst { it >= 0.45 * maxCol }
        val right = colCnt.indexOfLast { it >= 0.45 * maxCol }
        if (top < 0 || left < 0) return null
        val bw = (right - left).toDouble()
        val bh = (bottom - top).toDouble()
        if (bw < 0.35 * w || bh <= 0) return null
        val ratio = bw / bh
        if (ratio < 1.4 || ratio > 2.6) return null

        val inset = cushionInsetPct / 100.0 * bh
        val l = left + inset
        val t = top + inset
        val r = right - inset
        val b = bottom - inset
        val ballR = (r - l) / 88.8 * ballScale
        val table = Table(l, t, r, b, ballR)

        // 3. ball candidates
        val x0 = max(0, (l - 0.5 * ballR).toInt())
        val y0 = max(0, (t - 0.5 * ballR).toInt())
        val x1 = min(w - 1, (r + 0.5 * ballR).toInt())
        val y1 = min(hh - 1, (b + 0.5 * ballR).toInt())
        val rw = x1 - x0 + 1
        val rh = y1 - y0 + 1
        if (rw < 50 || rh < 30) return null

        val big = 1e6f
        val dist = FloatArray(rw * rh)
        for (yy in 0 until rh) for (xx in 0 until rw) {
            dist[yy * rw + xx] = if (!cloth[(yy + y0) * w + xx + x0]) big else 0f
        }
        val diag = 1.414f
        for (yy in 0 until rh) for (xx in 0 until rw) {
            val i = yy * rw + xx
            if (dist[i] == 0f) continue
            val lft = if (xx > 0) dist[i - 1] else 0f
            val up = if (yy > 0) dist[i - rw] else 0f
            val ul = if (xx > 0 && yy > 0) dist[i - rw - 1] else 0f
            val ur = if (xx < rw - 1 && yy > 0) dist[i - rw + 1] else 0f
            dist[i] = minOf(dist[i], lft + 1f, up + 1f, ul + diag, ur + diag)
        }
        for (yy in rh - 1 downTo 0) for (xx in rw - 1 downTo 0) {
            val i = yy * rw + xx
            if (dist[i] == 0f) continue
            val rgt = if (xx < rw - 1) dist[i + 1] else 0f
            val dn = if (yy < rh - 1) dist[i + rw] else 0f
            val dr = if (xx < rw - 1 && yy < rh - 1) dist[i + rw + 1] else 0f
            val dl = if (xx > 0 && yy < rh - 1) dist[i + rw - 1] else 0f
            dist[i] = minOf(dist[i], rgt + 1f, dn + 1f, dr + diag, dl + diag)
        }

        val found = ArrayList<Pair<Vec, Double>>() // centre, white fraction
        val kinds = ArrayList<BallKind>()
        val whites = ArrayList<Double>()
        for (iter in 0 until 24) {
            var best = 0f
            var bi = -1
            for (i in dist.indices) if (dist[i] > best) { best = dist[i]; bi = i }
            if (bi < 0 || best < 0.62 * ballR) break
            val px0 = bi % rw
            val py0 = bi / rw
            // refine: centroid of the plateau near the peak
            var sx = 0.0; var sy = 0.0; var cnt = 0
            val rr = ballR.toInt() + 1
            for (dy in -rr..rr) for (dx in -rr..rr) {
                val xx = px0 + dx; val yy = py0 + dy
                if (xx < 0 || yy < 0 || xx >= rw || yy >= rh) continue
                if (dist[yy * rw + xx] >= 0.9f * best) { sx += xx; sy += yy; cnt++ }
            }
            val cxl = if (cnt > 0) sx / cnt else px0.toDouble()
            val cyl = if (cnt > 0) sy / cnt else py0.toDouble()
            val centre = Vec(cxl + x0, cyl + y0)

            val clearR = max(1.15 * ballR, best + 1.0)
            val cr = clearR.toInt() + 1
            for (dy in -cr..cr) for (dx in -cr..cr) {
                val xx = (cxl + dx).toInt(); val yy = (cyl + dy).toInt()
                if (xx < 0 || yy < 0 || xx >= rw || yy >= rh) continue
                if (sqrt((dx * dx + dy * dy).toDouble()) <= clearR) dist[yy * rw + xx] = 0f
            }

            if (best > 1.5 * ballR) continue // too big to be a ball (HUD, text, ...)
            val nearPocket = table.pockets.indices.any {
                centre.dist(table.pockets[it]) < (if (table.isSide(it)) 1.8 else 2.2) * ballR
            }
            if (nearPocket) continue

            // classify by colour inside the disc
            var white = 0; var dark = 0; var total = 0
            val sr = (0.75 * ballR).toInt()
            for (dy in -sr..sr) for (dx in -sr..sr) {
                if (dx * dx + dy * dy > sr * sr) continue
                val xx = (centre.x + dx).toInt(); val yy = (centre.y + dy).toInt()
                if (xx < 0 || yy < 0 || xx >= w || yy >= hh) continue
                val i = yy * w + xx
                total++
                if (s[i] < 22 && v[i] > 75) white++
                if (v[i] < 30) dark++
            }
            if (total == 0) continue
            val wf = white.toDouble() / total
            val df = dark.toDouble() / total
            val kind = when {
                wf >= 0.80 -> BallKind.CUE
                df >= 0.45 -> BallKind.EIGHT
                wf >= 0.22 -> BallKind.STRIPE
                else -> BallKind.SOLID
            }
            found.add(centre to wf); kinds.add(kind); whites.add(wf)
        }

        // keep a single cue ball (the whitest one)
        var cueIdx = -1
        for (i in kinds.indices) if (kinds[i] == BallKind.CUE && (cueIdx < 0 || whites[i] > whites[cueIdx])) cueIdx = i
        val balls = found.indices.map { i ->
            val k = if (kinds[i] == BallKind.CUE && i != cueIdx) BallKind.STRIPE else kinds[i]
            Ball(found[i].first, k)
        }
        return Detection(table, balls)
    }
}
