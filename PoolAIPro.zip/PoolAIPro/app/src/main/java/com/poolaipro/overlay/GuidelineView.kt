package com.poolaipro.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import com.poolaipro.Settings
import com.poolaipro.core.Shot
import com.poolaipro.core.Vec
import com.poolaipro.core.polylineLength
import com.poolaipro.vision.UiState

/** Transparent, non-touchable full-screen layer that draws the predictions. */
class GuidelineView(ctx: Context) : View(ctx) {

    @Volatile private var state: UiState? = null
    private val dp = ctx.resources.displayMetrics.density

    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 12 * dp; setShadowLayer(3f, 0f, 0f, Color.BLACK) }
    private val path = Path()

    fun update(s: UiState) { state = s; postInvalidate() }

    override fun onDraw(c: Canvas) {
        val s = state ?: return
        val sx = width.toFloat() / s.fw
        val sy = height.toFloat() / s.fh
        fun X(v: Vec) = (v.x * sx).toFloat()
        fun Y(v: Vec) = (v.y * sy).toFloat()

        // status chip
        text.color = Color.WHITE
        c.drawText(s.status, 12 * dp, 22 * dp, text)

        val a = s.analysis ?: return
        val t = a.table
        val rPx = (t.ballR * sx).toFloat()
        val thick = Settings.lineThicknessDp * dp
        val maxLen = t.width * Settings.lineLength

        if (Settings.showTableBox) {
            line.color = Color.argb(110, 255, 255, 255); line.strokeWidth = 1.5f * dp; line.pathEffect = DashPathEffect(floatArrayOf(10f, 8f), 0f)
            c.drawRect((t.left * sx).toFloat(), (t.top * sy).toFloat(), (t.right * sx).toFloat(), (t.bottom * sy).toFloat(), line)
            line.pathEffect = null
            line.color = Color.argb(150, 255, 200, 0)
            for (p in t.pockets) c.drawCircle(X(p), Y(p), (1.6 * t.ballR * sx).toFloat(), line)
            // detected balls
            for (b in a.balls) c.drawCircle(X(b.pos), Y(b.pos), rPx, line)
        }
        if (!Settings.showPredictions || a.shots.isEmpty()) return

        c.save()
        c.clipRect(((t.left - t.ballR) * sx).toFloat(), ((t.top - t.ballR) * sy).toFloat(), ((t.right + t.ballR) * sx).toFloat(), ((t.bottom + t.ballR) * sy).toFloat())
        for (i in a.shots.indices.reversed()) drawShot(c, a.shots[i], i == 0, rPx, thick, maxLen, sx, sy)
        c.restore()

        // labels (outside clip)
        for ((i, sh) in a.shots.withIndex()) {
            val label = buildString {
                append("${sh.ease}% ")
                append(if (sh.isBank) "${sh.rails.size}-rail" else "direct")
                if (i == 0) append(" · cut ${sh.cutAngleDeg.toInt()}°")
                if (sh.scratchRisk) append(" · scratch risk")
            }
            text.color = if (i == 0) Color.rgb(120, 255, 170) else Color.rgb(255, 190, 90)
            c.drawText(label, X(sh.ghost) + rPx * 1.6f, Y(sh.ghost) - rPx * 1.2f, text)
        }
    }

    private fun drawShot(c: Canvas, sh: Shot, best: Boolean, rPx: Float, thick: Float, maxLen: Double, sx: Float, sy: Float) {
        fun X(v: Vec) = (v.x * sx).toFloat()
        fun Y(v: Vec) = (v.y * sy).toFloat()
        val w = if (best) thick else thick * 0.6f
        val alpha = if (best) 255 else 150
        val cue = sh.cueLeg[0]
        val dir = (sh.ghost - cue).unit()

        if (best) { // extended aim axis behind the cue ball
            val back = cue - dir * (maxLen * 0.35)
            line.color = Color.argb(90, 255, 255, 255); line.strokeWidth = w * 0.5f
            c.drawLine(X(back), Y(back), X(cue), Y(cue), line)
        }
        // cue ball -> ghost ball
        line.color = if (best) Color.argb(alpha, 0, 220, 255) else Color.argb(alpha, 255, 170, 60)
        line.strokeWidth = w; line.pathEffect = null
        c.drawLine(X(cue), Y(cue), X(sh.ghost), Y(sh.ghost), line)
        // ghost ball
        line.color = Color.argb(alpha, 255, 255, 255); line.strokeWidth = w * 0.7f
        c.drawCircle(X(sh.ghost), Y(sh.ghost), rPx, line)
        // target highlight
        line.color = Color.argb(alpha, 255, 80, 80)
        c.drawCircle(X(sh.target.pos), Y(sh.target.pos), rPx * 1.25f, line)

        // object ball path (cushion bounces marked)
        line.color = if (sh.isBank) Color.argb(alpha, 255, 230, 60) else Color.argb(alpha, 90, 255, 130)
        line.strokeWidth = w
        drawPoly(c, truncate(sh.objectPath, maxLen), sx, sy)
        fill.color = line.color
        for (i in 1 until sh.objectPath.size - 1) c.drawCircle(X(sh.objectPath[i]), Y(sh.objectPath[i]), w * 1.4f, fill)
        // pocket
        line.color = Color.argb(alpha, 90, 255, 130)
        val pk = sh.objectPath.last()
        c.drawCircle(X(pk), Y(pk), rPx * 1.5f, line)

        // cue ball after contact (dashed)
        if (best && sh.cueAfter.size > 1) {
            line.color = Color.argb(200, 255, 255, 255); line.strokeWidth = w * 0.8f
            line.pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f)
            drawPoly(c, truncate(sh.cueAfter, maxLen * 0.6), sx, sy)
            line.pathEffect = null
        }
    }

    private fun drawPoly(c: Canvas, pts: List<Vec>, sx: Float, sy: Float) {
        if (pts.size < 2) return
        path.reset()
        path.moveTo((pts[0].x * sx).toFloat(), (pts[0].y * sy).toFloat())
        for (i in 1 until pts.size) path.lineTo((pts[i].x * sx).toFloat(), (pts[i].y * sy).toFloat())
        c.drawPath(path, line)
    }

    /** Cut a polyline to at most [maxLen] pixels (frame space). */
    private fun truncate(pts: List<Vec>, maxLen: Double): List<Vec> {
        if (polylineLength(pts) <= maxLen) return pts
        val out = mutableListOf(pts[0])
        var left = maxLen
        for (i in 1 until pts.size) {
            val seg = pts[i].dist(pts[i - 1])
            if (seg >= left) { out.add(pts[i - 1] + (pts[i] - pts[i - 1]).unit() * left); break }
            out.add(pts[i]); left -= seg
        }
        return out
    }
}
