package com.poolaipro

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings as SysSettings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.poolaipro.overlay.ControlPanel
import com.poolaipro.overlay.GuidelineView
import com.poolaipro.vision.Analyzer
import com.poolaipro.vision.Frame
import kotlin.math.max

/**
 * Foreground service that owns the user-approved MediaProjection, the analysis loop and the overlay windows.
 * Nothing is recorded or stored: frames are analysed in memory and discarded.
 */
class AnalysisService : Service() {

    companion object {
        const val ACTION_START = "com.poolaipro.START"
        const val ACTION_STOP = "com.poolaipro.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "pool_ai_pro"
        private const val LONG_SIDE = 1152
        private const val MIN_FRAME_GAP_MS = 140L
        @Volatile var running = false
    }

    private lateinit var wm: WindowManager
    private lateinit var thread: HandlerThread
    private lateinit var handler: Handler
    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: GuidelineView? = null
    private var panel: ControlPanel? = null
    private val analyzer = Analyzer()
    private var bitmap: Bitmap? = null
    private var pixels = IntArray(0)
    private var lastFrame = 0L
    private var capW = 0
    private var capH = 0

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        thread = HandlerThread("pool-ai-capture").also { it.start() }
        handler = Handler(thread.looper)
        Settings.load(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopAnalysis(); return START_NOT_STICKY }
            ACTION_START -> if (!running) start(intent)
        }
        return START_NOT_STICKY
    }

    private fun start(intent: Intent) {
        startForegroundCompat()
        if (!SysSettings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow “Display over other apps” first", Toast.LENGTH_LONG).show()
            stopAnalysis(); return
        }
        val code = intent.getIntExtra(EXTRA_CODE, 0)
        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else intent.getParcelableExtra(EXTRA_DATA)
        if (data == null) { stopAnalysis(); return }

        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = try { mpm.getMediaProjection(code, data) } catch (e: Exception) { null }
        val proj = projection ?: run { stopAnalysis(); return }
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { stopAnalysis() } } // user ended sharing from system UI
        }, handler)

        startCapture(proj)
        addOverlays()
        running = true
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CHANNEL, "Pool AI Pro", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, AnalysisService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Pool AI Pro is analysing your shared screen")
            .setContentText("Screen sharing is active. Tap Stop to end it.")
            .setOngoing(true)
            .addAction(0, "Stop", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    @Suppress("DEPRECATION")
    private fun realMetrics(): DisplayMetrics {
        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        return m
    }

    private fun frameSize(m: DisplayMetrics): Pair<Int, Int> {
        val sc = LONG_SIDE.toFloat() / max(m.widthPixels, m.heightPixels)
        val s = if (sc < 1f) sc else 1f
        return Pair((m.widthPixels * s).toInt() and 1.inv(), (m.heightPixels * s).toInt() and 1.inv())
    }

    private fun startCapture(proj: MediaProjection) {
        val m = realMetrics()
        val (w, h) = frameSize(m)
        capW = w; capH = h
        val r = newReader(w, h)
        reader = r
        display = proj.createVirtualDisplay(
            "PoolAIPro", w, h, m.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler
        )
    }

    private fun newReader(w: Int, h: Int): ImageReader =
        ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2).also { it.setOnImageAvailableListener({ rd -> onImage(rd) }, handler) }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        handler.post {
            val vd = display ?: return@post
            val m = realMetrics()
            val (w, h) = frameSize(m)
            if (w == capW && h == capH) return@post
            val old = reader
            val nr = newReader(w, h)
            vd.resize(w, h, m.densityDpi)
            vd.surface = nr.surface
            reader = nr; capW = w; capH = h
            old?.close()
            overlay?.post { overlay?.let { v -> wm.updateViewLayout(v, overlayParams(m)) } }
        }
    }

    private fun onImage(rd: ImageReader) {
        val img = try { rd.acquireLatestImage() } catch (e: Exception) { null } ?: return
        try {
            val now = SystemClock.uptimeMillis()
            if (now - lastFrame < MIN_FRAME_GAP_MS) return
            lastFrame = now
            val plane = img.planes[0]
            val rowPx = plane.rowStride / plane.pixelStride
            var bmp = bitmap
            if (bmp == null || bmp.width != rowPx || bmp.height != img.height) {
                bmp?.recycle()
                bmp = Bitmap.createBitmap(rowPx, img.height, Bitmap.Config.ARGB_8888)
                bitmap = bmp
            }
            bmp.copyPixelsFromBuffer(plane.buffer)
            if (pixels.size != img.width * img.height) pixels = IntArray(img.width * img.height)
            bmp.getPixels(pixels, 0, img.width, 0, 0, img.width, img.height)
            overlay?.update(analyzer.process(Frame(img.width, img.height, pixels)))
        } catch (e: Exception) {
            // skip a bad frame
        } finally {
            img.close()
        }
    }

    private fun overlayParams(m: DisplayMetrics) = WindowManager.LayoutParams(
        m.widthPixels, m.heightPixels,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
    }

    private fun addOverlays() {
        val v = GuidelineView(this)
        wm.addView(v, overlayParams(realMetrics()))
        overlay = v
        val p = ControlPanel(this, wm) { stopAnalysis() }
        p.show()
        panel = p
    }

    private fun stopAnalysis() {
        running = false
        try { panel?.hide() } catch (_: Exception) {}
        panel = null
        try { overlay?.let { wm.removeView(it) } } catch (_: Exception) {}
        overlay = null
        try { display?.release() } catch (_: Exception) {}
        display = null
        try { reader?.close() } catch (_: Exception) {}
        reader = null
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
        bitmap?.recycle(); bitmap = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (running) stopAnalysis()
        thread.quitSafely()
        super.onDestroy()
    }
}
