package com.poolaipro.core

import kotlin.math.acos
import kotlin.math.exp
import kotlin.math.roundToInt

data class Shot(
    val target: Ball,
    val pocket: Int,
    val rails: List<Rail>,
    val ghost: Vec,
    val cueLeg: List<Vec>,      // cue ball -> ghost ball
    val objectPath: List<Vec>,  // target ball -> pocket (with cushion bounces)
    val cueAfter: List<Vec>,    // predicted cue-ball path after contact (no spin)
    val cutAngleDeg: Double,
    val scratchRisk: Boolean,
    val ease: Int,              // 0..100, higher = easier
    val score: Double
) {
    val isBank get() = rails.isNotEmpty()
}

data class EngineConfig(
    val maxRails: Int = 3,      // 0 = direct shots only, 1..3 = allow bank shots
    val group: Group = Group.ANY,
    val maxShots: Int = 3
)

data class Analysis(
    val table: Table,
    val cue: Ball?,
    val balls: List<Ball>,
    val shots: List<Shot>,
    val blockedCount: Int
)

object ShotEngine {

    private val RAILS = Rail.values().toList()

    private fun allowed(kind: BallKind, g: Group) = when (kind) {
        BallKind.CUE -> false
        BallKind.EIGHT -> g == Group.EIGHT || g == Group.ANY
        BallKind.SOLID -> g == Group.SOLIDS || g == Group.ANY
        BallKind.STRIPE -> g == Group.STRIPES || g == Group.ANY
    }

    private fun sequences(k: Int): List<List<Rail>> {
        var cur: List<List<Rail>> = RAILS.map { listOf(it) }
        repeat(k - 1) { cur = cur.flatMap { s -> RAILS.filter { it != s.last() }.map { s + it } } }
        return cur
    }
    private val SEQS = (1..3).associateWith { sequences(it) }

    fun analyse(table: Table, balls: List<Ball>, cfg: EngineConfig): Analysis {
        val cue = balls.firstOrNull { it.kind == BallKind.CUE }
            ?: return Analysis(table, null, balls, emptyList(), 0)
        val shots = ArrayList<Shot>()
        var blocked = 0

        for (t in balls.filter { allowed(it.kind, cfg.group) }) {
            val seen = HashSet<String>()
            val objObstacles = balls.filter { it !== t }
            val cueObstacles = balls.filter { it !== t && it !== cue }

            fun consider(pocket: Int, rails: List<Rail>, path: List<Vec>) {
                if (!seen.add("$pocket:${rails.joinToString()}")) return
                val s = evaluate(table, cue, t, pocket, rails, path, objObstacles, cueObstacles)
                if (s == null) blocked++ else shots.add(s)
            }

            // Direct shots
            for (pi in table.pockets.indices) {
                val p = table.pockets[pi]
                val d = (p - t.pos).unit()
                if (!table.entryOk(pi, d)) continue
                consider(pi, emptyList(), listOf(t.pos, p))
            }
            // Bank shots (object ball off 1..3 cushions), solved by mirroring the pocket
            for (k in 1..cfg.maxRails.coerceAtMost(3)) {
                for (seq in SEQS.getValue(k)) {
                    for (pi in table.pockets.indices) {
                        var m = table.pockets[pi]
                        for (i in k - 1 downTo 0) m = table.mirror(m, seq[i])
                        val dir = (m - t.pos).unit()
                        if (dir.len() < 0.5) continue
                        val r = table.simulate(t.pos, dir, table.width * 6, k)
                        if (r.pocket < 0 || r.rails.size != k) continue
                        consider(r.pocket, r.rails, r.points)
                    }
                }
            }
        }

        shots.sortBy { it.score }
        return Analysis(table, cue, balls, shots.take(cfg.maxShots), blocked)
    }

    private fun segmentClear(a: Vec, b: Vec, obstacles: List<Ball>, minDist: Double) =
        obstacles.none { distPointSegment(it.pos, a, b) < minDist }

    private fun evaluate(
        table: Table, cue: Ball, t: Ball, pocket: Int, rails: List<Rail>, path: List<Vec>,
        objObstacles: List<Ball>, cueObstacles: List<Ball>
    ): Shot? {
        val R = table.ballR
        if (path.size < 2) return null
        val d0 = (path[1] - path[0]).unit()
        val ghost = t.pos - d0 * (2 * R)
        if (!table.insideCentres(ghost)) return null

        val toGhost = ghost - cue.pos
        if (toGhost.len() < 1e-6) return null
        val cueDir = toGhost.unit()
        val cut = Math.toDegrees(acos(cueDir.dot(d0).coerceIn(-1.0, 1.0)))
        if (cut > 80.0) return null

        val clearance = 2 * R * 0.96
        if (!segmentClear(cue.pos, ghost, cueObstacles, clearance)) return null
        for (i in 1 until path.size) if (!segmentClear(path[i - 1], path[i], objObstacles, clearance)) return null

        // Cue ball after contact (stun/rolling ignored): leaves along the tangent line.
        val tangent = cueDir - d0 * cueDir.dot(d0)
        var scratch = false
        val cueAfter: List<Vec> = if (tangent.len() < 0.12) {
            listOf(ghost)
        } else {
            val r = table.simulate(ghost, tangent.unit(), table.width * 0.9, 2)
            scratch = r.pocket >= 0
            r.points
        }

        val objLen = polylineLength(path)
        var score = cut * 0.9 + (toGhost.len() + objLen) / R * 0.30 + rails.size * 22.0
        if (cut > 60) score += cut - 60
        if (scratch) score += 35.0
        val ease = (100.0 * exp(-score / 100.0)).roundToInt().coerceIn(1, 99)

        return Shot(t, pocket, rails, ghost, listOf(cue.pos, ghost), path, cueAfter, cut, scratch, ease, score)
    }
}
