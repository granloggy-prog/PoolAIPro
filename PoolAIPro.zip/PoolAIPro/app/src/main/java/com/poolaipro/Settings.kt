package com.poolaipro

import android.content.Context

/** User-tunable options shared by the overlay panel and the analyser. */
object Settings {
    @Volatile var showPredictions = true
    @Volatile var lineLength = 1.2f          // in table lengths
    @Volatile var lineThicknessDp = 2.5f
    @Volatile var cushionInsetPct = 3.0f     // % of table height
    @Volatile var ballScale = 1.0f
    @Volatile var maxRails = 3
    @Volatile var groupOrdinal = 0
    @Volatile var maxShots = 3
    @Volatile var showTableBox = true

    private const val FILE = "pool_ai_pro"

    fun load(ctx: Context) {
        val p = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        showPredictions = p.getBoolean("showPredictions", showPredictions)
        lineLength = p.getFloat("lineLength", lineLength)
        lineThicknessDp = p.getFloat("lineThicknessDp", lineThicknessDp)
        cushionInsetPct = p.getFloat("cushionInsetPct", cushionInsetPct)
        ballScale = p.getFloat("ballScale", ballScale)
        maxRails = p.getInt("maxRails", maxRails)
        groupOrdinal = p.getInt("groupOrdinal", groupOrdinal)
        showTableBox = p.getBoolean("showTableBox", showTableBox)
    }

    fun save(ctx: Context) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putBoolean("showPredictions", showPredictions)
            .putFloat("lineLength", lineLength)
            .putFloat("lineThicknessDp", lineThicknessDp)
            .putFloat("cushionInsetPct", cushionInsetPct)
            .putFloat("ballScale", ballScale)
            .putInt("maxRails", maxRails)
            .putInt("groupOrdinal", groupOrdinal)
            .putBoolean("showTableBox", showTableBox)
            .apply()
    }
}
