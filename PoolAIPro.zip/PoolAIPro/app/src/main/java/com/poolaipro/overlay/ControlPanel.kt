package com.poolaipro.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import com.poolaipro.Settings

/** Small movable floating window with the live controls. It is a separate window from the game. */
class ControlPanel(
    private val ctx: Context,
    private val wm: WindowManager,
    private val onStop: () -> Unit
) {
    private val dp = ctx.resources.displayMetrics.density
    private fun dp(v: Int) = (v * dp).toInt()
    private val groups = listOf("Any ball", "Solids", "Stripes", "8-ball")

    private val root = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(10), dp(6), dp(10), dp(8))
        background = GradientDrawable().apply { setColor(Color.argb(210, 14, 26, 31)); cornerRadius = dp(14).toFloat() }
    }
    private val body = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private val lp = WindowManager.LayoutParams(
        dp(230), WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(16); y = dp(60) }

    init { build() }

    fun show() { wm.addView(root, lp) }
    fun hide() { try { wm.removeView(root) } catch (_: Exception) {} }

    @SuppressLint("ClickableViewAccessibility")
    private fun build() {
        val header = TextView(ctx).apply {
            text = "◉ Pool AI Pro   ⠿ drag · tap to fold"
            setTextColor(Color.rgb(46, 230, 197)); textSize = 12f
            setPadding(0, dp(4), 0, dp(6))
        }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        header.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - sx) > 8 || Math.abs(e.rawY - sy) > 8) moved = true
                    if (moved) { lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(root, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) body.visibility = if (body.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            }
            true
        }
        root.addView(header)

        body.addView(toggle("Show predictions", Settings.showPredictions) { Settings.showPredictions = it })
        body.addView(toggle("Show table / ball box", Settings.showTableBox) { Settings.showTableBox = it })
        body.addView(seek("Line length (table lengths)", 20, 300, (Settings.lineLength * 100).toInt(), { it / 100f }) { Settings.lineLength = it.toFloat() / 100f })
        body.addView(seek("Line thickness", 1, 10, Settings.lineThicknessDp.toInt(), { it.toString() }) { Settings.lineThicknessDp = it.toFloat() })
        body.addView(seek("Max cushions (0 = direct only)", 0, 3, Settings.maxRails, { it.toString() }) { Settings.maxRails = it })
        body.addView(seek("Cushion inset % (calibrate)", 0, 80, (Settings.cushionInsetPct * 10).toInt(), { it / 10f }) { Settings.cushionInsetPct = it / 10f })
        body.addView(seek("Ball size % (calibrate)", 70, 130, (Settings.ballScale * 100).toInt(), { it.toString() }) { Settings.ballScale = it / 100f })

        val groupBtn = Button(ctx).apply {
            text = "Target: ${groups[Settings.groupOrdinal]}"
            setOnClickListener {
                Settings.groupOrdinal = (Settings.groupOrdinal + 1) % groups.size
                text = "Target: ${groups[Settings.groupOrdinal]}"; Settings.save(ctx)
            }
        }
        body.addView(groupBtn)
        body.addView(Button(ctx).apply { text = "Stop analysis"; setOnClickListener { Settings.save(ctx); onStop() } })
        root.addView(body)
    }

    private fun label(t: String) = TextView(ctx).apply { text = t; setTextColor(Color.WHITE); textSize = 11f; setPadding(0, dp(4), 0, 0) }

    private fun toggle(name: String, init: Boolean, cb: (Boolean) -> Unit) = Switch(ctx).apply {
        text = name; setTextColor(Color.WHITE); textSize = 12f; isChecked = init
        setOnCheckedChangeListener { _, on -> cb(on); Settings.save(ctx) }
    }

    /** Slider whose raw value is min..max; [fmt] renders the label, [set] applies it. */
    private fun <T> seek(name: String, min: Int, max: Int, value: Int, fmt: (Int) -> T, set: (Int) -> Unit): View {
        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val tv = label("$name: ${fmt(value)}")
        val sb = SeekBar(ctx).apply {
            this.max = max - min; progress = (value - min).coerceIn(0, max - min)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val raw = p + min; tv.text = "$name: ${fmt(raw)}"; set(raw)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { Settings.save(ctx) }
            })
        }
        box.addView(tv); box.addView(sb)
        return box
    }
}
