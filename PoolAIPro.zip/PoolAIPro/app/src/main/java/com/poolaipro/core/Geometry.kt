package com.poolaipro.core

import kotlin.math.*

data class Vec(val x: Double, val y: Double) {
    operator fun plus(o: Vec) = Vec(x + o.x, y + o.y)
    operator fun minus(o: Vec) = Vec(x - o.x, y - o.y)
    operator fun times(k: Double) = Vec(x * k, y * k)
    fun dot(o: Vec) = x * o.x + y * o.y
    fun len() = hypot(x, y)
    fun dist(o: Vec) = (this - o).len()
    fun unit(): Vec {
        val l = len()
        return if (l < 1e-9) Vec(0.0, 0.0) else Vec(x / l, y / l)
    }
}

enum class BallKind { CUE, EIGHT, SOLID, STRIPE }
enum class Rail { LEFT, RIGHT, TOP, BOTTOM }
enum class Group { ANY, SOLIDS, STRIPES, EIGHT }

data class Ball(val pos: Vec, val kind: BallKind)

/**
 * Playing surface = inner edge of the cushions (pixels of the analysed frame).
 * Ball centres can only travel inside the rectangle inset by one ball radius.
 * Pockets: 0 TL, 1 TM, 2 TR, 3 BL, 4 BM, 5 BR.
 */
class Table(val left: Double, val top: Double, val right: Double, val bottom: Double, val ballR: Double) {
    val width get() = right - left
    val height get() = bottom - top
    val minX get() = left + ballR
    val maxX get() = right - ballR
    val minY get() = top + ballR
    val maxY get() = bottom - ballR
    private val cx get() = (left + right) / 2

    val pockets: List<Vec> = listOf(
        Vec(left, top), Vec(cx, top), Vec(right, top),
        Vec(left, bottom), Vec(cx, bottom), Vec(right, bottom)
    )
    val pocketAxis: List<Vec> = listOf(
        Vec(1.0, 1.0).unit(), Vec(0.0, 1.0), Vec(-1.0, 1.0).unit(),
        Vec(1.0, -1.0).unit(), Vec(0.0, -1.0), Vec(-1.0, -1.0).unit()
    )

    fun isSide(i: Int) = i == 1 || i == 4
    fun captureR(i: Int) = if (isSide(i)) 1.45 * ballR else 1.85 * ballR

    /** Ball travelling in direction d may drop in pocket i only if it arrives at a sensible angle. */
    fun entryOk(i: Int, d: Vec): Boolean {
        val limit = if (isSide(i)) cos(Math.toRadians(62.0)) else cos(Math.toRadians(70.0))
        return (d * -1.0).dot(pocketAxis[i]) >= limit
    }

    fun mirror(p: Vec, r: Rail): Vec = when (r) {
        Rail.LEFT -> Vec(2 * minX - p.x, p.y)
        Rail.RIGHT -> Vec(2 * maxX - p.x, p.y)
        Rail.TOP -> Vec(p.x, 2 * minY - p.y)
        Rail.BOTTOM -> Vec(p.x, 2 * maxY - p.y)
    }

    fun insideCentres(p: Vec, slack: Double = 0.6 * ballR) =
        p.x >= minX - slack && p.x <= maxX + slack && p.y >= minY - slack && p.y <= maxY + slack
}

class PathResult(val points: List<Vec>, val rails: List<Rail>, val pocket: Int)

/** Trace a ball centre from [start] along [dir], reflecting off cushions, stopping in a pocket. */
fun Table.simulate(start: Vec, dir0: Vec, maxLen: Double, maxRails: Int): PathResult {
    var pos = Vec(start.x.coerceIn(minX, maxX), start.y.coerceIn(minY, maxY))
    var d = dir0.unit()
    val pts = mutableListOf(pos)
    val rails = mutableListOf<Rail>()
    var remaining = maxLen
    var guard = 0
    while (remaining > 1e-6 && guard++ < 12) {
        val tx = when {
            d.x > 1e-12 -> (maxX - pos.x) / d.x
            d.x < -1e-12 -> (minX - pos.x) / d.x
            else -> Double.POSITIVE_INFINITY
        }
        val ty = when {
            d.y > 1e-12 -> (maxY - pos.y) / d.y
            d.y < -1e-12 -> (minY - pos.y) / d.y
            else -> Double.POSITIVE_INFINITY
        }
        val tWall = min(tx, ty)
        val t = min(tWall, remaining)

        var bestIdx = -1
        var bestS = Double.MAX_VALUE
        for (i in pockets.indices) {
            val p = pockets[i]
            val s = (p - pos).dot(d).coerceIn(0.0, t)
            if ((pos + d * s).dist(p) <= captureR(i) && s < bestS && entryOk(i, d)) {
                bestIdx = i; bestS = s
            }
        }
        if (bestIdx >= 0) {
            pts.add(pockets[bestIdx])
            return PathResult(pts, rails, bestIdx)
        }

        val end = pos + d * t
        pts.add(end)
        if (remaining <= tWall) break
        if (rails.size >= maxRails) break
        if (abs(tx - ty) < 1e-9) break // dead corner: stop
        if (tx < ty) {
            rails.add(if (d.x > 0) Rail.RIGHT else Rail.LEFT)
            d = Vec(-d.x, d.y)
        } else {
            rails.add(if (d.y > 0) Rail.BOTTOM else Rail.TOP)
            d = Vec(d.x, -d.y)
        }
        pos = end
        remaining -= t
    }
    return PathResult(pts, rails, -1)
}

fun distPointSegment(p: Vec, a: Vec, b: Vec): Double {
    val ab = b - a
    val l2 = ab.dot(ab)
    if (l2 < 1e-12) return p.dist(a)
    val t = ((p - a).dot(ab) / l2).coerceIn(0.0, 1.0)
    return p.dist(a + ab * t)
}

fun polylineLength(pts: List<Vec>): Double {
    var s = 0.0
    for (i in 1 until pts.size) s += pts[i].dist(pts[i - 1])
    return s
}
